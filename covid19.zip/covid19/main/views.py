from django.shortcuts import render

import requests
import json
# Create your views here.

def index(request):
    url = "http://covid19-india-adhikansh.herokuapp.com/summary/"
    data =requests.get(url)
    alldata= data.json()
    context={
        'total':alldata['Total Cases'],
        'active':alldata['Active cases'],
        'recover':alldata['Cured/Discharged/Migrated'],
        'death':alldata['Death']
    }
    return render(request,'index.htm',context)