import json
import requests

def Covid(total):
    url = 'http://covid19-india-adhikansh.herokuapp.com/summary'
    params = {'total',total}
    r = requests.get(url,params=params)
    data = r.json()
    context={
        'total':data['Total Cases'],
        'active':data['Active cases']
    }
    return context
